
export const getData = (page)=>{
    let contextData = {};
    switch (page) {
        default:
            contextData = { ...contextData }
    }
    return {...contextData, ...getAllPageContext()};
}


function getAllPageContext() {
    return {
    }
}